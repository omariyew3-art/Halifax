'use client';

import { useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { Shield, Zap, Lock } from 'lucide-react';
import { LoginForm } from '@/components/auth/LoginForm';
import { useApp } from '@/store/AppContext';

export default function LoginPage() {
  const { state } = useApp();
  const router = useRouter();

  useEffect(() => {
    if (state.isAuthenticated) {
      router.replace('/dashboard');
    }
  }, [state.isAuthenticated, router]);

  return (
    <div className="min-h-screen flex bg-gradient-to-br from-slate-50 via-blue-50/30 to-slate-100">
      <div className="hidden lg:flex lg:w-1/2 relative bg-gradient-to-br from-blue-800 via-blue-700 to-blue-900 p-12 flex-col justify-between overflow-hidden">
        <div className="absolute inset-0 overflow-hidden">
          <div className="absolute top-0 right-0 w-96 h-96 rounded-full bg-blue-600/30 -translate-y-1/3 translate-x-1/3 blur-3xl" />
          <div className="absolute bottom-0 left-0 w-80 h-80 rounded-full bg-blue-500/20 translate-y-1/3 -translate-x-1/4 blur-3xl" />
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px]"
            style={{
              backgroundImage: 'radial-gradient(circle, rgba(255,255,255,0.03) 1px, transparent 1px)',
              backgroundSize: '32px 32px',
            }}
          />
        </div>

        <div className="relative z-10">
          <div className="flex items-center gap-3 mb-16">
            <img src="/images_(1).png" alt="Halifax" className="h-10 w-auto object-contain brightness-0 invert" />
          </div>

          <h1 className="text-4xl font-bold text-white leading-tight mb-4">
            Banking made<br />
            <span className="text-blue-300">beautifully simple.</span>
          </h1>
          <p className="text-blue-200 text-lg leading-relaxed max-w-sm">
            Manage your money with confidence. Fast transfers, real-time tracking, and total control.
          </p>
        </div>

        <div className="relative z-10 space-y-4">
          {[
            { icon: Shield, title: 'Bank-grade Security', desc: 'Your money is protected 24/7' },
            { icon: Zap, title: 'Instant Transfers', desc: 'Send money in seconds' },
            { icon: Lock, title: 'Privacy First', desc: 'Your data stays yours' },
          ].map(({ icon: Icon, title, desc }) => (
            <div key={title} className="flex items-center gap-4">
              <div className="w-10 h-10 rounded-xl bg-white/10 flex items-center justify-center flex-shrink-0">
                <Icon size={18} className="text-blue-200" />
              </div>
              <div>
                <p className="text-white font-semibold text-sm">{title}</p>
                <p className="text-blue-300 text-xs">{desc}</p>
              </div>
            </div>
          ))}
        </div>
      </div>

      <div className="flex-1 flex items-center justify-center p-6 sm:p-10">
        <div className="w-full max-w-sm">
          <div className="lg:hidden flex items-center gap-2.5 mb-10">
            <img src="/images_(1).png" alt="Halifax" className="h-9 w-auto object-contain" />
          </div>

          <div className="mb-8">
            <h2 className="text-2xl font-bold text-slate-900 mb-1">Welcome back</h2>
            <p className="text-slate-500 text-sm">Sign in to access your account</p>
          </div>

          <div className="bg-white rounded-3xl border border-slate-100 shadow-xl p-6 sm:p-8">
            <LoginForm />
          </div>

          <p className="mt-6 text-center text-xs text-slate-400">
            Halifax Digital Bank &copy; {new Date().getFullYear()}
          </p>
        </div>
      </div>
    </div>
  );
}
