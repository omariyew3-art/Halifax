'use client';

import { useState } from 'react';
import { Copy, Check, Share2 } from 'lucide-react';
import { useApp } from '@/store/AppContext';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';

interface ReceiveModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function ReceiveModal({ open, onOpenChange }: ReceiveModalProps) {
  const { state } = useApp();
  const [copiedField, setCopiedField] = useState<string | null>(null);

  const copyToClipboard = (text: string, field: string) => {
    navigator.clipboard.writeText(text).catch(() => {});
    setCopiedField(field);
    setTimeout(() => setCopiedField(null), 2000);
  };

  const accountNumber = state.user?.accountNumber ?? '****7842';
  const sortCode = state.user?.sortCode ?? '20-41-**';
  const name = state.user?.name ?? 'Account Holder';

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-sm rounded-3xl border-slate-100 shadow-2xl p-0 overflow-hidden">
        <div className="bg-gradient-to-r from-emerald-600 to-teal-500 p-6 text-white">
          <DialogHeader>
            <DialogTitle className="text-white text-xl font-bold">Receive Money</DialogTitle>
            <p className="text-emerald-100 text-sm mt-0.5">Share your account details</p>
          </DialogHeader>
        </div>

        <div className="p-6 space-y-4">
          <div className="bg-emerald-50 border border-emerald-100 rounded-2xl p-4 text-center space-y-1">
            <p className="text-xs font-semibold text-emerald-500 uppercase tracking-wider">Account Holder</p>
            <p className="text-lg font-bold text-slate-800">{name}</p>
          </div>

          <div className="space-y-2.5">
            <DetailRow
              label="Account Number"
              value={accountNumber}
              onCopy={() => copyToClipboard(accountNumber, 'account')}
              copied={copiedField === 'account'}
            />
            <DetailRow
              label="Sort Code"
              value={sortCode}
              onCopy={() => copyToClipboard(sortCode, 'sort')}
              copied={copiedField === 'sort'}
            />
            <DetailRow
              label="Bank"
              value="Halifax Digital Bank"
              onCopy={() => copyToClipboard('Halifax Digital Bank', 'bank')}
              copied={copiedField === 'bank'}
            />
          </div>

          <div className="bg-blue-50 border border-blue-100 rounded-2xl p-3 text-center">
            <p className="text-xs text-blue-600 font-medium">
              Share these details with anyone who wants to send you money via bank transfer.
            </p>
          </div>

          <Button
            variant="outline"
            className="w-full rounded-xl h-11 border-slate-200 gap-2"
            onClick={() => {
              const text = `Bank: Halifax Digital Bank\nAccount: ${accountNumber}\nSort Code: ${sortCode}\nName: ${name}`;
              if (navigator.share) {
                navigator.share({ title: 'My Bank Details', text });
              } else {
                copyToClipboard(text, 'all');
              }
            }}
          >
            <Share2 size={15} />
            Share Details
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}

function DetailRow({
  label,
  value,
  onCopy,
  copied,
}: {
  label: string;
  value: string;
  onCopy: () => void;
  copied: boolean;
}) {
  return (
    <div className="flex items-center justify-between bg-slate-50 border border-slate-100 rounded-xl px-4 py-3">
      <div>
        <p className="text-xs text-slate-400 font-medium">{label}</p>
        <p className="text-sm font-semibold text-slate-800 font-mono">{value}</p>
      </div>
      <button
        onClick={onCopy}
        className="p-2 rounded-lg hover:bg-slate-200 transition-colors text-slate-400 hover:text-slate-600"
      >
        {copied ? <Check size={15} className="text-emerald-500" /> : <Copy size={15} />}
      </button>
    </div>
  );
}
