'use client';

import { useState } from 'react';
import { User, Lock, Bell, Shield, ChevronRight, Check, Eye, EyeOff } from 'lucide-react';
import { Sheet, SheetContent, SheetHeader, SheetTitle } from '@/components/ui/sheet';
import { useApp } from '@/store/AppContext';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';

interface SettingsModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

type Section = 'home' | 'profile' | 'security' | 'notifications';

const NAV_ITEMS = [
  { key: 'profile' as Section, icon: User, label: 'Personal Details', desc: 'Name, email, phone number' },
  { key: 'security' as Section, icon: Lock, label: 'Security', desc: 'Password and two-factor auth' },
  { key: 'notifications' as Section, icon: Bell, label: 'Notification Preferences', desc: 'Alerts, emails, and push' },
];

const NOTIFICATION_PREFS = [
  { key: 'transfers', label: 'Transfer alerts', desc: 'When money is sent or received' },
  { key: 'login', label: 'Login alerts', desc: 'New sign-in to your account' },
  { key: 'statements', label: 'Monthly statements', desc: 'When your statement is ready' },
  { key: 'promotions', label: 'Offers & news', desc: 'Product updates and promotions' },
];

export function SettingsModal({ open, onOpenChange }: SettingsModalProps) {
  const { state } = useApp();
  const [section, setSection] = useState<Section>('home');
  const [saved, setSaved] = useState(false);
  const [showOld, setShowOld] = useState(false);
  const [showNew, setShowNew] = useState(false);
  const [notifPrefs, setNotifPrefs] = useState({ transfers: true, login: true, statements: true, promotions: false });

  const handleClose = () => {
    onOpenChange(false);
    setTimeout(() => { setSection('home'); setSaved(false); }, 300);
  };

  const handleSave = async () => {
    setSaved(true);
    setTimeout(() => setSaved(false), 2500);
  };

  const togglePref = (key: keyof typeof notifPrefs) => {
    setNotifPrefs((p) => ({ ...p, [key]: !p[key] }));
  };

  return (
    <Sheet open={open} onOpenChange={handleClose}>
      <SheetContent side="right" className="w-full sm:max-w-sm p-0 flex flex-col">
        <div className="bg-gradient-to-r from-slate-800 to-slate-700 p-5 text-white flex-shrink-0">
          <SheetHeader>
            <div className="flex items-center gap-3">
              {section !== 'home' && (
                <button
                  onClick={() => setSection('home')}
                  className="w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center transition-colors"
                >
                  <ChevronRight size={15} className="text-white rotate-180" />
                </button>
              )}
              <div>
                <SheetTitle className="text-white text-xl font-bold">
                  {section === 'home' ? 'Settings' : NAV_ITEMS.find((n) => n.key === section)?.label}
                </SheetTitle>
                <p className="text-slate-300 text-sm mt-0.5">
                  {section === 'home' ? 'Manage your account' : 'Update your preferences'}
                </p>
              </div>
            </div>
          </SheetHeader>
        </div>

        <div className="flex-1 overflow-y-auto">
          {section === 'home' && (
            <div className="p-5 space-y-4">
              <div className="flex items-center gap-3 p-4 bg-slate-50 rounded-2xl border border-slate-100">
                <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-blue-600 to-blue-800 flex items-center justify-center shadow-sm">
                  <span className="text-white font-bold text-sm">{state.user?.avatarInitials ?? 'U'}</span>
                </div>
                <div>
                  <p className="font-bold text-slate-800">{state.user?.name ?? 'Account Holder'}</p>
                  <p className="text-sm text-slate-500">{state.user?.email}</p>
                </div>
              </div>

              <div className="space-y-2">
                {NAV_ITEMS.map(({ key, icon: Icon, label, desc }) => (
                  <button
                    key={key}
                    onClick={() => setSection(key)}
                    className="w-full flex items-center gap-3 p-4 bg-white rounded-2xl border border-slate-100 hover:border-slate-200 shadow-sm hover:shadow transition-all text-left active:scale-[0.99]"
                  >
                    <div className="w-10 h-10 rounded-xl bg-slate-50 border border-slate-100 flex items-center justify-center flex-shrink-0">
                      <Icon size={18} className="text-slate-600" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-semibold text-slate-800">{label}</p>
                      <p className="text-xs text-slate-400">{desc}</p>
                    </div>
                    <ChevronRight size={15} className="text-slate-300 flex-shrink-0" />
                  </button>
                ))}
              </div>

              <div className="flex items-center gap-2.5 p-3.5 bg-emerald-50 border border-emerald-100 rounded-2xl">
                <Shield size={15} className="text-emerald-600 flex-shrink-0" />
                <p className="text-xs text-emerald-700 font-medium">Your account is protected and up to date.</p>
              </div>
            </div>
          )}

          {section === 'profile' && (
            <div className="p-5 space-y-4">
              <div className="space-y-3">
                <FormField label="Full Name" defaultValue={state.user?.name ?? ''} />
                <FormField label="Email Address" defaultValue={state.user?.email ?? ''} type="email" />
                <FormField label="Phone Number" defaultValue="+44 7700 900000" type="tel" />
                <FormField label="Date of Birth" defaultValue="12/08/1991" type="text" />
              </div>
              <SaveButton saved={saved} onSave={handleSave} />
            </div>
          )}

          {section === 'security' && (
            <div className="p-5 space-y-4">
              <div className="space-y-1.5">
                <Label className="text-sm font-semibold text-slate-700">Current Password</Label>
                <div className="relative">
                  <Input
                    type={showOld ? 'text' : 'password'}
                    placeholder="••••••••"
                    className="pr-10 rounded-xl border-slate-200 h-11 focus-visible:ring-blue-500"
                  />
                  <button
                    type="button"
                    onClick={() => setShowOld(!showOld)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
                  >
                    {showOld ? <EyeOff size={15} /> : <Eye size={15} />}
                  </button>
                </div>
              </div>
              <div className="space-y-1.5">
                <Label className="text-sm font-semibold text-slate-700">New Password</Label>
                <div className="relative">
                  <Input
                    type={showNew ? 'text' : 'password'}
                    placeholder="••••••••"
                    className="pr-10 rounded-xl border-slate-200 h-11 focus-visible:ring-blue-500"
                  />
                  <button
                    type="button"
                    onClick={() => setShowNew(!showNew)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
                  >
                    {showNew ? <EyeOff size={15} /> : <Eye size={15} />}
                  </button>
                </div>
              </div>

              <div className="p-3.5 bg-slate-50 border border-slate-100 rounded-xl space-y-1.5">
                <p className="text-xs font-semibold text-slate-600">Two-Factor Authentication</p>
                <p className="text-xs text-slate-400">Enabled via SMS to +44 7700 ••••00</p>
                <span className="inline-flex items-center gap-1 text-xs font-semibold text-emerald-600">
                  <Check size={11} /> Active
                </span>
              </div>

              <SaveButton saved={saved} onSave={handleSave} />
            </div>
          )}

          {section === 'notifications' && (
            <div className="p-5 space-y-3">
              {NOTIFICATION_PREFS.map(({ key, label, desc }) => (
                <div
                  key={key}
                  className="flex items-center justify-between p-4 bg-white rounded-2xl border border-slate-100 shadow-sm"
                >
                  <div className="flex-1 min-w-0 pr-3">
                    <p className="text-sm font-semibold text-slate-800">{label}</p>
                    <p className="text-xs text-slate-400">{desc}</p>
                  </div>
                  <button
                    onClick={() => togglePref(key as keyof typeof notifPrefs)}
                    className={`relative w-11 h-6 rounded-full transition-colors flex-shrink-0 ${
                      notifPrefs[key as keyof typeof notifPrefs] ? 'bg-blue-600' : 'bg-slate-200'
                    }`}
                  >
                    <span
                      className={`absolute top-0.5 left-0.5 w-5 h-5 rounded-full bg-white shadow-sm transition-transform ${
                        notifPrefs[key as keyof typeof notifPrefs] ? 'translate-x-5' : 'translate-x-0'
                      }`}
                    />
                  </button>
                </div>
              ))}
              <SaveButton saved={saved} onSave={handleSave} />
            </div>
          )}
        </div>
      </SheetContent>
    </Sheet>
  );
}

function FormField({ label, defaultValue, type = 'text' }: { label: string; defaultValue: string; type?: string }) {
  return (
    <div className="space-y-1.5">
      <Label className="text-sm font-semibold text-slate-700">{label}</Label>
      <Input
        type={type}
        defaultValue={defaultValue}
        className="rounded-xl border-slate-200 h-11 focus-visible:ring-blue-500"
      />
    </div>
  );
}

function SaveButton({ saved, onSave }: { saved: boolean; onSave: () => void }) {
  return (
    <Button
      onClick={onSave}
      className={`w-full rounded-xl h-11 font-semibold gap-2 transition-all ${
        saved ? 'bg-emerald-600 hover:bg-emerald-700' : 'bg-blue-600 hover:bg-blue-700'
      }`}
    >
      {saved ? <><Check size={16} /> Saved</> : 'Save Changes'}
    </Button>
  );
}
