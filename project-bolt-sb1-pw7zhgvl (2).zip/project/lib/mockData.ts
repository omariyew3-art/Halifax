import { Transaction, User } from './types';

export const DEFAULT_USER: User = {
  name: 'Alex Morgan',
  email: 'alex.morgan@example.com',
  accountNumber: '****7842',
  sortCode: '20-41-**',
  avatarInitials: 'AM',
};

export const INITIAL_BALANCE = 340000.0;

function generateId(): string {
  return Math.random().toString(36).slice(2, 11).toUpperCase();
}

function daysAgo(days: number, hours = 0): string {
  const d = new Date();
  d.setDate(d.getDate() - days);
  d.setHours(d.getHours() - hours);
  return d.toISOString();
}

export const SEED_TRANSACTIONS: Transaction[] = [
  {
    id: generateId(),
    type: 'credit',
    amount: 3200.0,
    description: 'Monthly Salary',
    recipient: 'Apex Technologies Ltd',
    category: 'salary',
    timestamp: daysAgo(1, 2),
    status: 'completed',
    reference: 'SALARY-' + generateId(),
  },
  {
    id: generateId(),
    type: 'debit',
    amount: 89.99,
    description: 'Netflix & Spotify Bundle',
    recipient: 'Entertainment Services',
    category: 'entertainment',
    timestamp: daysAgo(2, 4),
    status: 'completed',
    reference: 'ENT-' + generateId(),
  },
  {
    id: generateId(),
    type: 'debit',
    amount: 142.5,
    description: 'Whole Foods Market',
    recipient: 'Whole Foods',
    category: 'food',
    timestamp: daysAgo(3, 1),
    status: 'completed',
    reference: 'SHOP-' + generateId(),
  },
  {
    id: generateId(),
    type: 'debit',
    amount: 55.0,
    description: 'Uber Rides — Weekly',
    recipient: 'Uber',
    category: 'transport',
    timestamp: daysAgo(4, 6),
    status: 'completed',
    reference: 'TRN-' + generateId(),
  },
  {
    id: generateId(),
    type: 'credit',
    amount: 250.0,
    description: 'Freelance Design Project',
    recipient: 'Studio Nine',
    category: 'transfer',
    timestamp: daysAgo(5, 3),
    status: 'completed',
    reference: 'TRF-' + generateId(),
  },
  {
    id: generateId(),
    type: 'debit',
    amount: 180.0,
    description: 'Electricity & Gas Bill',
    recipient: 'British Gas',
    category: 'utilities',
    timestamp: daysAgo(7, 9),
    status: 'completed',
    reference: 'UTIL-' + generateId(),
  },
  {
    id: generateId(),
    type: 'debit',
    amount: 32.4,
    description: 'Deliveroo — Dinner',
    recipient: 'Deliveroo',
    category: 'food',
    timestamp: daysAgo(8, 11),
    status: 'completed',
    reference: 'FOOD-' + generateId(),
  },
  {
    id: generateId(),
    type: 'debit',
    amount: 299.0,
    description: 'Apple MacBook Accessories',
    recipient: 'Apple Store',
    category: 'shopping',
    timestamp: daysAgo(10, 2),
    status: 'completed',
    reference: 'SHOP-' + generateId(),
  },
  {
    id: generateId(),
    type: 'credit',
    amount: 75.0,
    description: 'Reimbursement from James',
    recipient: 'James Whitfield',
    category: 'transfer',
    timestamp: daysAgo(12, 5),
    status: 'completed',
    reference: 'TRF-' + generateId(),
  },
  {
    id: generateId(),
    type: 'debit',
    amount: 12.5,
    description: 'TfL Contactless Payment',
    recipient: 'Transport for London',
    category: 'transport',
    timestamp: daysAgo(14, 7),
    status: 'completed',
    reference: 'TRN-' + generateId(),
  },
];

export const CATEGORY_ICONS: Record<string, string> = {
  salary: '💼',
  entertainment: '🎬',
  food: '🍔',
  transport: '🚗',
  transfer: '↔️',
  utilities: '⚡',
  shopping: '🛍️',
  other: '📦',
};

export const MOCK_RECIPIENTS = [
  'Sarah Johnson',
  'James Whitfield',
  'Emma Clarke',
  'Oliver Bennett',
  'Mia Thompson',
  'Noah Williams',
  'Sophia Davis',
  'Liam Anderson',
];
