import { AppState, CardSettings } from './types';
import { DEFAULT_USER, INITIAL_BALANCE, SEED_TRANSACTIONS } from './mockData';

const STORAGE_KEY = 'halifax_state_v2';

const DEFAULT_CARD_SETTINGS: CardSettings = {
  frozen: false,
  contactless: true,
  onlinePayments: true,
};

export function loadState(): AppState {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return getDefaultState();
    const parsed = JSON.parse(raw) as Partial<AppState>;
    return {
      user: parsed.user ?? null,
      isAuthenticated: parsed.isAuthenticated ?? false,
      balance: parsed.balance ?? INITIAL_BALANCE,
      transactions: parsed.transactions ?? SEED_TRANSACTIONS,
      cardSettings: parsed.cardSettings ?? DEFAULT_CARD_SETTINGS,
    };
  } catch {
    return getDefaultState();
  }
}

export function saveState(state: AppState): void {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
  } catch (err) {
    console.warn('[Halifax] Could not save state:', err);
  }
}

export function clearState(): void {
  try {
    localStorage.removeItem(STORAGE_KEY);
  } catch (err) {
    console.warn('[Halifax] Could not clear state:', err);
  }
}

function getDefaultState(): AppState {
  return {
    user: null,
    isAuthenticated: false,
    balance: INITIAL_BALANCE,
    transactions: SEED_TRANSACTIONS,
    cardSettings: DEFAULT_CARD_SETTINGS,
  };
}

export function initializeStateWithUser(email: string): AppState {
  const existing = loadState();
  return {
    ...existing,
    user: {
      ...DEFAULT_USER,
      email,
    },
    isAuthenticated: true,
    balance: existing.isAuthenticated ? existing.balance : INITIAL_BALANCE,
    transactions: existing.isAuthenticated ? existing.transactions : SEED_TRANSACTIONS,
    cardSettings: existing.cardSettings ?? DEFAULT_CARD_SETTINGS,
  };
}
